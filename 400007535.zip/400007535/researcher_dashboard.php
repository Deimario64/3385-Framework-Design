<!DOCTYPE html>
<html>
<head>
    <title>Researcher Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="gridlvl5a">
  <div class="grid-item left med center">LOGO</div>
</div>

<div class="gridlvl5">
  <div class="grid-item center brdr">VIEW ALL STUDIES</div>
</div>

<div class="footer">
<h4> Copyright Deimario Callender. All Rights Reserved</h4>
</div>

</body>
</html>


