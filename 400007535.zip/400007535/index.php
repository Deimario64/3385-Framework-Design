<?php
require_once 'Controller/UmsController.php';
require_once 'Model/UmsModel.php';

// Create Database Link
$UmsController = new UmsController();

if (isset($_GET['action'])) {
    $action = $_GET['action'];
    switch ($action) {
        
        case 'login':
            $UmsController->login();
            break;//check

        case 'register':
            $UmsController->register();
            break;//check

        case 'create':
            $UmsController->create();
            break;

        case 'dashboard':
            $UmsController->dashboard();
            break;
    }
    }else{
        $UmsController->register();
} 