<?php
class UmsModel {
    private $usr;

    public function __construct() {
        $this->usr = new PDO("mysql:host=localhost; dbname=user_management_system", 'root', '');
    }

    public function register($username, $hashedPassword, $email) {
        $sql = "INSERT INTO users (username, password, email) VALUES (:username, :password, :email)";
        $stmt = $this->usr->prepare($sql);
        $stmt->execute([
            ':username' => $username,
            ':password' => $hashedPassword,
            ':email' => $email,
        ]);
    }

    public function getUserByEmail($email) {
        $sql = "SELECT * FROM users WHERE email = :email";
        $stmt = $this->usr->prepare($sql);
        $stmt->execute([':email' => $email]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    public function getUsernameById($userId) {
        $sql = "SELECT * FROM users WHERE id = :id";
        $stmt = $this->usr->prepare($sql);
        $stmt->execute([':id' => $userId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }


}
?>