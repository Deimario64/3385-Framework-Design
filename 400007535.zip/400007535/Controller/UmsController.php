<?php
require_once 'Model/UmsModel.php';

class UmsController {
    private $model;

    public function __construct() {
        $this->model = new UmsModel();
    }

    public function login() {
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $email = $_POST['email'];
                $password = $_POST['password'];
    
    
                if (empty($email) || empty($password)) {
                    echo '<div ><p>Please provide both email and password.</p></div>';
                    return;
                }
    
                $UmsModel = new UmsModel();
                $user = $UmsModel->getUserByEmail($email);
    
                if ($user && password_verify($password, $user['password'])) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_role'] = $user['role'];
                    $this->redirectToDashboard($user['role']);
                } else {
                    echo '<div><p>Invalid email/password.</p></div>';
                }
            }
        }
    private function redirectToDashboard($role) {
        // Redirect users to their respective dashboards based on their roles
        switch ($role) {
             case 'Research Group Manager':
                include 'research_group_manager_dashboard.php';
                break;
            case 'Research Study Manager':
                include 'research_study_manager_dashboard.php';
                break;
            case 'Researcher':
                include 'researcher_dashboard.php';
                break;
        }
        exit();
    }

    public function register() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'];
            $email = $_POST['email'];
            $password = $_POST['password'];

            $errors = [];

            if (strlen($username) < 3) {
                $errors[] = "Username must be at least 3 characters long.";
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = "Invalid email address.";
            }

            if (strlen($password) < 10 || !preg_match('/[A-Z]/', $password) || !preg_match('/\d/', $password)) {
                $errors[] = "Password must be at least 10 characters long, contain at least one uppercase letter, and one digit.";
            }
            if (empty($errors)) {
                // Hash the password
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

                // Save the user to the database
                $userModel = new UmsModel($this->usr);
                $userModel->register($username, $hashedPassword, $email); 

                // Redirect to the login page
                header("Location: login.php");
                exit();
                }else {
                    
                // Display validation errors
                echo '<div><ul>';
                foreach ($errors as $error) {
                    echo '<li>' . $error . '</li>';
                }
                echo '</ul></div>';
            }
        }
        include 'register.php';
    }
    public function create() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'];
            $email = $_POST['email'];
            $password = $_POST['password'];
            $role = $_POST['role'];

            $errors = [];

            if (strlen($username) < 3) {
                $errors[] = "Username must be at least 3 characters long.";
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = "Invalid email address.";
            }

            if (strlen($password) < 10 || !preg_match('/[A-Z]/', $password) || !preg_match('/\d/', $password)) {
                $errors[] = "Password must be at least 10 characters long, contain at least one uppercase letter, and one digit.";
            }
            if (empty($errors)) {
                // Hash the password
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

                // Save the user to the database
                $userModel = new UmsModel($this->usr);
                $userModel->createUser($username, $hashedPassword, $email); 

                // Redirect to the login page
                header("Location: login.php");
                exit();
                }else {
                    
                // Display validation errors
                echo '<div><ul>';
                foreach ($errors as $error) {
                    echo '<li>' . $error . '</li>';
                }
                echo '</ul></div>';
            }
        }
    }


/*     public function getLoggedInUsername() {
        if (isset($_SESSION['user_id'])) {
            $userId = $_SESSION['user_id'];
            return $this->model->getUsernameById($userId);
        }
        return "Unknown";
    }
    
    public function getLoggedInUserEmail() {
        if (isset($_SESSION['user_id'])) {
            $userId = $_SESSION['user_id'];
            return $this->model->getEmailById($userId);
        }
        return "Unknown";
    } */

    public function dashboard() {
        if (isset($_SESSION['user_role'])) {
            $role = $_SESSION['user_role'];
            $userModel = new UmsModel();
            $user = $userModel->getUserById($_SESSION['user_id']); 

            switch ($role) {
                case 'Research Group Manager':
                    $this->displayResearchGroupManagerDashboard();
                    break;
                case 'Research Study Manager':
                    $this->displayResearchStudyManagerDashboard();
                    break;
                case 'Researcher':
                    $this->displayResearcherDashboard();
                    break;
            }
        }
    }
    private function displayResearchGroupManagerDashboard() {
        // Display studies, create, view, edit, delete studies, create other users, etc.
    }

    private function displayResearchStudyManagerDashboard() {
        // Display studies, create, view, edit, delete studies, manage profiles, etc.
    }

    private function displayResearcherDashboard() {
        // Display studies, view and edit studies, etc.
    }

}
?>
