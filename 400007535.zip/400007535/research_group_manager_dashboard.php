<!DOCTYPE html>
<html>
<head>
    <title>Research Group Manager Dashboard</title>
    <link rel="stylesheet" href="style.css">

</head>
<body>
<div class="gridlvl1">
  <div class="grid-item left med">LOGO</div>
  <div class="grid-item right med">Log Out</div>
</div>

<div class="gridlvl1">
<div class="grid-item center ">RESEARCH GROUP MANAGER: USERNAME</div>  
  <div class="grid-item center ">EMAIL: IUGDFKDHG@FKJSDHGFKDJS.COM</div>
</div>
<div class="gridlvl1">
  <div class="grid-item center brdr">CREATE NEW STUDY</div>  
  <div class="grid-item center brdr">VIEW ALL STUDIES</div>
</div>
<div class="gridlvl1">
    <div class="grid-item center brdr">DELETE PREVIOUS STUDY</div>  
    <div class="grid-item center brdr">CREATE NEW RESEARCHERS</div>
</div>
<div class="footer">
<h4> Copyright Deimario Callender. All Rights Reserved</h4>
</div>

</body>
</html>


